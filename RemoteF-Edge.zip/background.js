(() => {
  // src/storage.js
  var Storage = class {
    constructor(prefix = "remotef_") {
      this.prefix = prefix;
      this.storage = chrome.storage.local;
    }
    // ===== 基础操作 =====
    async get(key) {
      const result = await this.storage.get(this.prefix + key);
      return result[this.prefix + key];
    }
    async set(key, value) {
      await this.storage.set({ [this.prefix + key]: value });
    }
    async remove(key) {
      await this.storage.remove(this.prefix + key);
    }
    async clear() {
      const keys = await this.storage.get(null);
      const prefixKeys = Object.keys(keys).filter((k) => k.startsWith(this.prefix));
      if (prefixKeys.length > 0) {
        await this.storage.remove(prefixKeys);
      }
    }
    // ===== 客户端身份（永久唯一 ID）=====
    /**
     * 获取客户端唯一 ID。
     * 首次调用时生成 UUID v4 并持久化到 storage，后续始终返回相同值。
     * 不受重连、更新、浏览器重启影响，只有卸载扩展才会消失。
     */
    async getClientId() {
      const KEY = "remotef_client_id";
      const result = await this.storage.get(KEY);
      if (result[KEY]) {
        return result[KEY];
      }
      const id = "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
        const r = crypto.getRandomValues(new Uint8Array(1))[0] & 15 | (c === "x" ? 0 : 128);
        return (c === "x" ? r : r & 63 | 128).toString(16);
      });
      await this.storage.set({ [KEY]: id });
      console.log("[Storage] \u751F\u6210\u5BA2\u6237\u7AEF\u552F\u4E00 ID:", id);
      return id;
    }
    // ===== 配置操作 =====
    async getConfig() {
      const result = await this.storage.get("remotef_config");
      return result["remotef_config"] || {
        serverUrl: "",
        autoConnect: true,
        clientName: "",
        clientVersion: "1.0.0"
      };
    }
    async saveConfig(config) {
      await this.storage.set({ "remotef_config": config });
    }
    // ===== 插件元数据操作 =====
    async getPluginMeta() {
      const result = await this.storage.get(this.prefix + "plugin_meta");
      return result[this.prefix + "plugin_meta"] || {};
    }
    async savePluginMeta(meta) {
      await this.storage.set({ [this.prefix + "plugin_meta"]: meta });
    }
    async getPluginData(name) {
      return this.get("plugin_" + name);
    }
    async savePluginData(name, data) {
      await this.set("plugin_" + name, data);
    }
    async removePluginData(name) {
      await this.remove("plugin_" + name);
      await this.remove("plugin_code_" + name);
    }
    async getPluginCode(name) {
      return this.get("plugin_code_" + name);
    }
    async savePluginCode(name, code) {
      await this.set("plugin_code_" + name, code);
    }
  };
  var storage_default = new Storage();

  // src/plugin-manager.js
  var PluginStatus = {
    INSTALLED: "installed",
    // 已安装（正常可用）
    ERROR: "error"
    // 异常（安装失败或运行出错）
  };
  function createPluginContext(pluginName, sendFunc) {
    return {
      pluginName,
      console: {
        log: (...args) => console.log(`[${pluginName}]`, ...args),
        error: (...args) => console.error(`[${pluginName}]`, ...args),
        warn: (...args) => console.warn(`[${pluginName}]`, ...args),
        info: (...args) => console.info(`[${pluginName}]`, ...args)
      },
      sendMessage: (msg) => {
        sendFunc({
          type: "plugin_message",
          payload: { pluginName, message: msg }
        });
      }
    };
  }
  var PluginManager = class {
    constructor() {
      this.plugins = /* @__PURE__ */ new Map();
      this.contexts = /* @__PURE__ */ new Map();
      this.eventListeners = /* @__PURE__ */ new Set();
    }
    // ===== 事件系统 =====
    on(event, callback) {
      const id = Symbol("listener");
      this.eventListeners.add({ id, event, callback });
      return () => this.off(id);
    }
    off(id) {
      for (const listener of this.eventListeners) {
        if (listener.id === id) {
          this.eventListeners.delete(listener);
          break;
        }
      }
    }
    emit(event, data = {}) {
      this.eventListeners.forEach((listener) => {
        if (listener.event === event || listener.event === "*") {
          try {
            listener.callback({ type: event, ...data });
          } catch (err) {
            console.error("[PluginManager] \u4E8B\u4EF6\u56DE\u8C03\u9519\u8BEF:", err);
          }
        }
      });
    }
    // ===== 插件安装 =====
    async install(pluginName, module, sendFunc) {
      console.log("[PluginManager] \u5B89\u88C5\u63D2\u4EF6:", pluginName);
      try {
        const meta = await storage_default.getPluginMeta();
        meta[pluginName] = {
          version: module.manifest.version,
          installedAt: Date.now(),
          lastError: null
        };
        await storage_default.savePluginMeta(meta);
        const pluginData = {
          manifest: module.manifest,
          version: module.manifest.version,
          files: module.files,
          installedAt: Date.now()
        };
        await storage_default.savePluginData(pluginName, pluginData);
        const mainFile = module.manifest.client?.entry || "content.js";
        const code = module.files[mainFile];
        if (code) {
          await storage_default.savePluginCode(pluginName, code);
        }
        this.plugins.set(pluginName, {
          name: pluginName,
          manifest: module.manifest,
          version: module.manifest.version,
          status: PluginStatus.INSTALLED,
          error: null,
          installedAt: pluginData.installedAt
        });
        console.log("[PluginManager] \u63D2\u4EF6\u5B89\u88C5\u6210\u529F:", pluginName);
        this.emit("installed", { pluginName, version: pluginData.version });
        return { success: true, plugin: this.plugins.get(pluginName) };
      } catch (err) {
        console.error("[PluginManager] \u63D2\u4EF6\u5B89\u88C5\u5931\u8D25:", pluginName, err);
        this.setStatus(pluginName, PluginStatus.ERROR, err.message);
        this.emit("error", { pluginName, error: err.message });
        return { success: false, error: err.message };
      }
    }
    // ===== 插件卸载 =====
    async uninstall(pluginName) {
      console.log("[PluginManager] \u5378\u8F7D\u63D2\u4EF6:", pluginName);
      try {
        await storage_default.removePluginData(pluginName);
        const plugin = this.plugins.get(pluginName);
        this.plugins.delete(pluginName);
        const meta = await storage_default.getPluginMeta();
        delete meta[pluginName];
        await storage_default.savePluginMeta(meta);
        const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
        if (tabs[0]?.id) {
          chrome.tabs.sendMessage(tabs[0].id, {
            target: "content",
            type: "plugin_unload",
            payload: { pluginName }
          });
        }
        console.log("[PluginManager] \u63D2\u4EF6\u5378\u8F7D\u6210\u529F:", pluginName);
        this.emit("uninstalled", { pluginName });
        return { success: true };
      } catch (err) {
        console.error("[PluginManager] \u63D2\u4EF6\u5378\u8F7D\u5931\u8D25:", pluginName, err);
        return { success: false, error: err.message };
      }
    }
    // ===== 手动重运行插件 =====
    async rerun(pluginName) {
      console.log("[PluginManager] \u624B\u52A8\u91CD\u8FD0\u884C\u63D2\u4EF6:", pluginName);
      const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
      if (!tabs[0]?.id) {
        return { success: false, error: "\u65E0\u6CD5\u83B7\u53D6\u5F53\u524D\u6807\u7B7E\u9875" };
      }
      try {
        await chrome.tabs.sendMessage(tabs[0].id, {
          target: "content",
          type: "plugin_rerun",
          payload: { pluginName }
        });
        return { success: true };
      } catch (err) {
        console.error("[PluginManager] \u91CD\u8FD0\u884C\u5931\u8D25:", err.message);
        return { success: false, error: err.message };
      }
    }
    // ===== 在标签页运行所有已安装插件 =====
    async runAllInTab(tabId, sendFunc) {
      console.log("[PluginManager] \u5728\u6807\u7B7E\u9875\u8FD0\u884C\u63D2\u4EF6:", tabId);
      const meta = await storage_default.getPluginMeta();
      const pluginNames = Object.keys(meta);
      for (const name of pluginNames) {
        try {
          const code = await storage_default.getPluginCode(name);
          if (!code)
            continue;
          console.log("[PluginManager] \u6267\u884C\u63D2\u4EF6:", name);
          if (typeof chrome.userScripts?.execute === "function") {
            const results = await chrome.userScripts.execute({
              target: { tabId },
              scripts: [{
                code: `
                (function() {
                  window.__remotef_plugins = window.__remotef_plugins || {};
                  try {
                    const factory = (${code});
                    window.__remotef_plugins['${name}'] = factory;
                    return { success: true, hasFactory: typeof factory === 'function' };
                  } catch (err) {
                    return { success: false, error: err.message };
                  }
                })();
              `
              }]
            });
            const result = results?.[0]?.result;
            if (result?.success) {
              console.log("[PluginManager]", name, ": \u6CE8\u5165\u6210\u529F (userScripts API)");
              const context = createPluginContext(name, sendFunc);
              chrome.tabs.sendMessage(tabId, {
                target: "content",
                type: "plugin_register",
                payload: { pluginName: name, context }
              });
            } else {
              console.error("[PluginManager]", name, ": \u6CE8\u5165\u5931\u8D25", result?.error);
            }
          } else {
            console.log("[PluginManager]", name, ": chrome.userScripts \u4E0D\u53EF\u7528\uFF0C\u964D\u7EA7\u5230 executeScript");
            const results = await new Promise((resolve, reject) => {
              chrome.scripting.executeScript({
                target: { tabId },
                world: "ISOLATED",
                func: (pluginName, pluginCode) => {
                  try {
                    window.__remotef_plugins = window.__remotef_plugins || {};
                    const factory = new Function(`return (${pluginCode})`)();
                    window.__remotef_plugins[pluginName] = factory;
                    return { success: !!factory, hasFactory: typeof factory === "function" };
                  } catch (err) {
                    return { success: false, error: err.message };
                  }
                },
                args: [name, code]
              }, (results2) => {
                if (chrome.runtime.lastError) {
                  reject(new Error(chrome.runtime.lastError.message));
                } else {
                  resolve(results2[0]?.result);
                }
              });
            });
            if (results?.success) {
              console.log("[PluginManager]", name, ": \u6CE8\u5165\u6210\u529F (executeScript)");
              const context = createPluginContext(name, sendFunc);
              chrome.tabs.sendMessage(tabId, {
                target: "content",
                type: "plugin_register",
                payload: { pluginName: name, context }
              });
            } else {
              console.error("[PluginManager]", name, ": \u6CE8\u5165\u5931\u8D25", results?.error);
            }
          }
        } catch (err) {
          console.error("[PluginManager]", name, ": \u9519\u8BEF:", err.message);
        }
      }
    }
    // ===== 上下文创建（用于服务端模块的 init/onEnable）=====
    createContext(pluginName, sendFunc) {
      const self = this;
      return {
        pluginName,
        sendMessage: (msg) => {
          sendFunc({
            type: "plugin_message",
            payload: { pluginName, message: msg }
          });
        },
        onMessage: (handler) => {
          self.contexts.set(pluginName, handler);
        }
      };
    }
    // ===== 状态管理 =====
    setStatus(pluginName, status, error = null) {
      const plugin = this.plugins.get(pluginName);
      if (plugin) {
        plugin.status = status;
        plugin.error = error;
        plugin.statusChangedAt = Date.now();
        this.emit("statusChanged", { pluginName, status, error });
      }
    }
    getStatus(pluginName) {
      return this.plugins.get(pluginName)?.status || null;
    }
    // ===== 查询方法 =====
    get(pluginName) {
      return this.plugins.get(pluginName) || null;
    }
    getAll() {
      return Array.from(this.plugins.values()).map((p) => ({
        name: p.name,
        manifest: p.manifest,
        version: p.version,
        status: p.status,
        error: p.error,
        installedAt: p.installedAt
      }));
    }
    getNames() {
      return Array.from(this.plugins.keys());
    }
    has(pluginName) {
      return this.plugins.has(pluginName);
    }
    getContextHandler(pluginName) {
      return this.contexts.get(pluginName);
    }
    // ===== 从存储恢复 =====
    async restore(sendFunc) {
      console.log("[PluginManager] \u6062\u590D\u5DF2\u5B89\u88C5\u7684\u63D2\u4EF6...");
      const meta = await storage_default.getPluginMeta();
      const names = Object.keys(meta);
      for (const name of names) {
        try {
          const data = await storage_default.getPluginData(name);
          if (data?.manifest) {
            this.plugins.set(name, {
              name,
              manifest: data.manifest,
              version: data.version,
              status: PluginStatus.INSTALLED,
              error: null,
              installedAt: data.installedAt
            });
            console.log("[PluginManager] \u6062\u590D\u63D2\u4EF6:", name);
          }
        } catch (err) {
          console.error("[PluginManager] \u6062\u590D\u63D2\u4EF6\u5931\u8D25:", name, err);
        }
      }
      this.emit("restored", { count: this.plugins.size });
      console.log("[PluginManager] \u63D2\u4EF6\u6062\u590D\u5B8C\u6210:", this.plugins.size);
    }
  };
  var plugin_manager_default = new PluginManager();

  // src/ws-client.js
  var WSClient = class {
    constructor() {
      this.ws = null;
      this.reconnectTimer = null;
      this.isConnected = false;
      this.clientId = null;
      this.messageHandlers = /* @__PURE__ */ new Map();
    }
    // ===== 连接管理 =====
    async connect() {
      console.log("[WSClient] connect() \u88AB\u8C03\u7528");
      const config = await storage_default.getConfig();
      if (!config.serverUrl) {
        console.log("[WSClient] \u672A\u914D\u7F6E\u670D\u52A1\u7AEF\u5730\u5740");
        this.updateBadge("\u914D\u7F6E", "gray");
        return;
      }
      this.clientId = await storage_default.getClientId();
      console.log("[WSClient] \u5BA2\u6237\u7AEF\u552F\u4E00 ID:", this.clientId);
      let wsUrl = config.serverUrl.trim();
      if (!wsUrl.startsWith("http://") && !wsUrl.startsWith("https://")) {
        wsUrl = "http://" + wsUrl;
      }
      wsUrl = wsUrl.replace(/^http/, "ws") + "/ws";
      console.log("[WSClient] \u6B63\u5728\u8FDE\u63A5 WebSocket:", wsUrl);
      if (this.ws) {
        console.log("[WSClient] \u5173\u95ED\u65E7\u8FDE\u63A5");
        this.ws.close();
        this.ws = null;
      }
      this.ws = new WebSocket(wsUrl);
      console.log("[WSClient] WebSocket \u5BF9\u8C61\u5DF2\u521B\u5EFA");
      this.setupHandlers(config);
    }
    setupHandlers(config) {
      this.ws.onopen = () => {
        console.log("[WSClient] WebSocket \u8FDE\u63A5\u6253\u5F00!");
        this.isConnected = true;
        clearTimeout(this.reconnectTimer);
        this.send({
          type: "register",
          payload: {
            clientId: this.clientId,
            name: config.clientName || this.clientId,
            version: config.clientVersion,
            platform: "chrome-extension",
            extensions: plugin_manager_default.getNames()
          }
        });
        this.updateBadge("\u5DF2\u8FDE\u63A5", "green");
        this.emit("connection_changed", { connected: true });
      };
      this.ws.onclose = (event) => {
        console.log("[WSClient] WebSocket \u8FDE\u63A5\u5173\u95ED:", event.code, event.reason);
        this.isConnected = false;
        this.ws = null;
        this.updateBadge("\u672A\u8FDE\u63A5", "red");
        this.emit("connection_changed", { connected: false });
        if (!event.wasClean && event.code !== 1e3) {
          console.log("[WSClient] \u51C6\u5907\u91CD\u8FDE...");
          this.reconnectTimer = setTimeout(() => this.connect(), 3e3);
        }
      };
      this.ws.onerror = (error) => {
        console.error("[WSClient] WebSocket \u9519\u8BEF:", error);
        this.updateBadge("\u9519\u8BEF", "red");
      };
      this.ws.onmessage = async (event) => {
        try {
          const message = JSON.parse(event.data);
          console.log("[WSClient] \u6536\u5230\u6D88\u606F:", message.type);
          const handler = this.messageHandlers.get(message.type);
          if (handler) {
            await handler(message.payload || {}, message);
          }
        } catch (err) {
          console.error("[WSClient] \u6D88\u606F\u5904\u7406\u9519\u8BEF:", err);
        }
      };
    }
    disconnect() {
      if (this.ws) {
        this.ws.close();
        this.ws = null;
      }
      this.isConnected = false;
      clearTimeout(this.reconnectTimer);
      this.updateBadge("\u672A\u8FDE\u63A5", "gray");
      this.emit("connection_changed", { connected: false });
    }
    // ===== 消息发送 =====
    send(message) {
      if (this.ws?.readyState === WebSocket.OPEN) {
        this.ws.send(JSON.stringify(message));
      } else {
        console.log("[WSClient] WebSocket \u672A\u8FDE\u63A5\uFF0C\u65E0\u6CD5\u53D1\u9001:", message.type);
      }
    }
    // ===== 消息处理注册 =====
    onMessage(type, handler) {
      this.messageHandlers.set(type, handler);
    }
    offMessage(type) {
      this.messageHandlers.delete(type);
    }
    // ===== 事件系统 =====
    emit(event, data) {
      const handler = this.messageHandlers.get("_" + event);
      if (handler) {
        handler(data);
      }
    }
    on(event, handler) {
      this.messageHandlers.set("_" + event, handler);
    }
    // ===== 状态更新 =====
    updateBadge(text, color) {
      const colors = {
        green: "#4CAF50",
        red: "#f44336",
        gray: "#9e9e9e",
        blue: "#2196F3",
        yellow: "#FFC107"
      };
      chrome.action.setBadgeText({ text: text || "" });
      chrome.action.setBadgeBackgroundColor({ color: colors[color] || colors.gray });
    }
    // ===== 状态查询 =====
    getStatus() {
      return {
        isConnected: this.isConnected,
        clientId: this.clientId
      };
    }
  };
  var ws_client_default = new WSClient();

  // src/api.js
  var ClientAPI = class {
    constructor() {
      this.messageHandlers = /* @__PURE__ */ new Map();
      this.pendingRequests = /* @__PURE__ */ new Map();
      this.requestTimeout = 3e4;
    }
    // ===== 连接状态 =====
    /**
     * 获取 WebSocket 连接状态
     * @returns {{ connected: boolean, clientId: string|null, serverUrl: string|null }}
     */
    getConnectionStatus() {
      return {
        connected: ws_client_default.isConnected,
        clientId: ws_client_default.clientId,
        serverUrl: ws_client_default.ws?.url || null
      };
    }
    /**
     * 获取客户端唯一 ID
     * @returns {Promise<string>}
     */
    async getClientId() {
      return storage_default.getClientId();
    }
    // ===== 插件与服务端通讯 =====
    /**
     * 发送消息给同名的服务端插件
     * pluginName 由系统自动绑定，插件无法指定或冒充其他插件
     * @param {string} pluginName - 由系统注入的插件名（内部使用）
     * @param {object} message - 消息内容
     * @returns {boolean} 是否发送成功
     */
    sendMessage(pluginName, message) {
      if (!ws_client_default.isConnected) {
        console.warn("[ClientAPI] \u672A\u8FDE\u63A5\uFF0C\u65E0\u6CD5\u53D1\u9001\u6D88\u606F");
        return false;
      }
      ws_client_default.send({
        type: "plugin_message",
        payload: { pluginName, message }
      });
      return true;
    }
    /**
     * 发送消息给同名服务端插件并等待响应
     * @param {string} pluginName - 由系统注入的插件名（内部使用）
     * @param {object} message - 消息内容
     * @param {number} [timeout=30000] - 超时时间（毫秒）
     * @returns {Promise<object>} 服务端响应
     */
    sendMessageWithResponse(pluginName, message, timeout) {
      return new Promise((resolve, reject) => {
        if (!ws_client_default.isConnected) {
          reject(new Error("\u672A\u8FDE\u63A5\u5230\u670D\u52A1\u7AEF"));
          return;
        }
        const requestId = `${Date.now()}-${Math.random().toString(36).substring(2, 8)}`;
        const actualTimeout = timeout || this.requestTimeout;
        const timer = setTimeout(() => {
          this.pendingRequests.delete(requestId);
          reject(new Error(`\u8BF7\u6C42\u8D85\u65F6 (${actualTimeout}ms)`));
        }, actualTimeout);
        this.pendingRequests.set(requestId, { resolve, reject, timer });
        ws_client_default.send({
          type: "plugin_message",
          payload: {
            pluginName,
            message: { ...message, __requestId: requestId }
          }
        });
      });
    }
    /**
     * 注册消息处理器（只接收发给本插件的消息）
     * @param {string} pluginName - 插件名（由系统注入）
     * @param {function} handler - 消息处理函数 (message) => void
     */
    onMessage(pluginName, handler) {
      this.messageHandlers.set(pluginName, handler);
    }
    /**
     * 取消消息处理器
     * @param {string} pluginName - 插件名
     */
    offMessage(pluginName) {
      this.messageHandlers.delete(pluginName);
    }
    /**
     * 处理来自服务端的插件消息（只分发给同名插件）
     * @param {object} payload - { pluginName, message }
     */
    handleServerMessage(payload) {
      const { pluginName, message } = payload;
      if (message?.__requestId) {
        const pending = this.pendingRequests.get(message.__requestId);
        if (pending) {
          clearTimeout(pending.timer);
          this.pendingRequests.delete(message.__requestId);
          pending.resolve(message);
          return;
        }
      }
      const handler = this.messageHandlers.get(pluginName);
      if (handler) {
        try {
          handler(message);
        } catch (err) {
          console.error(`[ClientAPI] \u63D2\u4EF6 ${pluginName} \u6D88\u606F\u5904\u7406\u9519\u8BEF:`, err);
        }
      }
    }
    // ===== 存储操作 =====
    /**
     * 获取插件存储数据
     * @param {string} pluginName - 插件名（由系统注入）
     * @param {string} key - 存储键
     * @returns {Promise<any>}
     */
    async getStorage(pluginName, key) {
      const data = await storage_default.get(`plugin_storage_${pluginName}`);
      return data?.[key] ?? null;
    }
    /**
     * 设置插件存储数据
     * @param {string} pluginName - 插件名（由系统注入）
     * @param {string} key - 存储键
     * @param {any} value - 存储值
     */
    async setStorage(pluginName, key, value) {
      const data = await storage_default.get(`plugin_storage_${pluginName}`) || {};
      data[key] = value;
      await storage_default.set(`plugin_storage_${pluginName}`, data);
    }
    /**
     * 删除插件存储数据
     * @param {string} pluginName - 插件名（由系统注入）
     * @param {string} key - 存储键
     */
    async removeStorage(pluginName, key) {
      const data = await storage_default.get(`plugin_storage_${pluginName}`) || {};
      delete data[key];
      await storage_default.set(`plugin_storage_${pluginName}`, data);
    }
    // ===== 插件信息 =====
    /**
     * 获取已安装插件列表
     * @returns {Promise<Array>}
     */
    async getInstalledPlugins() {
      const meta = await storage_default.getPluginMeta();
      return Object.entries(meta).map(([name, info]) => ({
        name,
        version: info.version,
        installedAt: info.installedAt
      }));
    }
    // ===== 清理 =====
    /**
     * 清理指定插件的所有注册和存储
     * @param {string} pluginName - 插件名
     */
    cleanup(pluginName) {
      this.messageHandlers.delete(pluginName);
    }
  };
  var api_default = new ClientAPI();

  // src/messenger.js
  var popupListeners = /* @__PURE__ */ new Set();
  function broadcastToPopup(message) {
    chrome.runtime.sendMessage({ type: "popup_update", payload: message }).catch(() => {
    });
    popupListeners.forEach((listener) => {
      try {
        listener(message);
      } catch {
        popupListeners.delete(listener);
      }
    });
  }
  function addPopupListener(listener) {
    popupListeners.add(listener);
    return () => popupListeners.delete(listener);
  }
  async function handlePluginList(plugins) {
    console.log("[RemoteF] \u6536\u5230\u63D2\u4EF6\u5217\u8868:", plugins);
    broadcastToPopup({ type: "plugin_list", plugins });
    const localMeta = await storage_default.getPluginMeta();
    console.log("[RemoteF] \u5F00\u59CB\u540C\u6B65\u63D2\u4EF6...");
    for (const serverPlugin of plugins) {
      const localVersion = localMeta[serverPlugin.name]?.version;
      if (localVersion && localVersion === serverPlugin.version) {
        console.log(`[RemoteF] \u5DF2\u5B89\u88C5: ${serverPlugin.name} v${serverPlugin.version}`);
      } else {
        const action = localVersion ? "\u66F4\u65B0" : "\u5B89\u88C5";
        const versionInfo = localVersion ? ` (${localVersion} -> ${serverPlugin.version})` : "";
        console.log(`[RemoteF] \u9700\u8981${action}: ${serverPlugin.name}${versionInfo}`);
        requestPluginInstall(serverPlugin.name);
      }
    }
  }
  function requestPluginInstall(pluginName) {
    ws_client_default.send({ type: "plugin_install", payload: { pluginName } });
  }
  async function handlePluginPush(payload) {
    const { pluginName, module } = payload;
    console.log("[RemoteF] \u6536\u5230\u63D2\u4EF6\u5185\u5BB9:", pluginName);
    const result = await plugin_manager_default.install(pluginName, module, (msg) => ws_client_default.send(msg));
    ws_client_default.send({
      type: "plugin_install_result",
      payload: { pluginName, ...result }
    });
  }
  function handlePluginMessage(payload) {
    const { pluginName, message } = payload;
    const handler = plugin_manager_default.getContextHandler(pluginName);
    if (handler) {
      try {
        handler(message);
      } catch (err) {
        console.error(`[RemoteF] \u63D2\u4EF6\u6D88\u606F\u5904\u7406\u9519\u8BEF (${pluginName}):`, err);
      }
    } else {
      console.log(`[RemoteF] \u672A\u627E\u5230\u63D2\u4EF6\u5904\u7406\u5668: ${pluginName}`);
    }
  }
  function setupMessageHandlers() {
    chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
      console.log("[RemoteF] \u6536\u5230 API \u6D88\u606F:", msg.type);
      switch (msg.type) {
        case "get_status": {
          const plugins = plugin_manager_default.getAll();
          sendResponse({
            isConnected: ws_client_default.isConnected,
            clientId: ws_client_default.clientId,
            plugins
          });
          break;
        }
        case "get_plugins":
          sendResponse({ plugins: plugin_manager_default.getAll() });
          break;
        case "get_plugin_status":
          sendResponse({
            status: plugin_manager_default.getStatus(msg.pluginName),
            error: plugin_manager_default.getError(msg.pluginName)
          });
          break;
        case "connect":
          ws_client_default.connect().then(() => sendResponse({ success: true }));
          break;
        case "disconnect":
          ws_client_default.disconnect();
          sendResponse({ success: true });
          break;
        case "popup_subscribe": {
          addPopupListener(sendResponse);
          return true;
        }
      }
      return false;
    });
  }

  // src/background.js
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.target === "background") {
      handleBackgroundMessage(message, sender, sendResponse);
      return true;
    }
  });
  async function handleBackgroundMessage(message, sender, sendResponse) {
    const { type, payload } = message;
    switch (type) {
      case "get_plugins_with_code": {
        try {
          const meta = await storage_default.getPluginMeta();
          const pluginNames = Object.keys(meta);
          const plugins = [];
          for (const name of pluginNames) {
            const code = await storage_default.getPluginCode(name);
            const data = await storage_default.getPluginData(name);
            const matches = data?.manifest?.matches || null;
            plugins.push({ name, code, matches });
          }
          sendResponse({ plugins });
        } catch (err) {
          sendResponse({ plugins: [], error: err.message });
        }
        return true;
      }
      case "get_plugin_code": {
        try {
          const code = await storage_default.getPluginCode(payload.pluginName);
          sendResponse({ code });
        } catch (err) {
          sendResponse({ code: null, error: err.message });
        }
        return true;
      }
      case "get_current_tab_id": {
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
          sendResponse({ tabId: tabs[0]?.id });
        });
        return true;
      }
      case "execute_plugin": {
        try {
          const { pluginName, pluginCode, tabId } = payload;
          const results = await new Promise((resolve, reject) => {
            chrome.scripting.executeScript({
              target: { tabId },
              world: "MAIN",
              func: executePluginInMainWorld,
              args: [pluginName, pluginCode]
            }, (results2) => {
              if (chrome.runtime.lastError) {
                reject(new Error(chrome.runtime.lastError.message));
              } else {
                resolve(results2?.[0]?.result);
              }
            });
          });
          sendResponse(results || { success: true });
        } catch (err) {
          sendResponse({ success: false, error: err.message });
        }
        return true;
      }
      case "plugin_to_server": {
        ws_client_default.send({
          type: "plugin_message",
          payload
        });
        sendResponse({ success: true });
        return true;
      }
      case "plugin_loaded": {
        console.log("[Background] \u63D2\u4EF6\u5DF2\u52A0\u8F7D:", payload.pluginName);
        sendResponse({ success: true });
        return true;
      }
      case "api_request": {
        handleApiRequest(payload, sendResponse);
        return true;
      }
      case "input_dispatch": {
        handleInputDispatch(payload, sender, sendResponse);
        return true;
      }
    }
  }
  function handleApiRequest(payload, sendResponse) {
    const { method, params } = payload;
    switch (method) {
      case "getConnectionStatus": {
        sendResponse(api_default.getConnectionStatus());
        break;
      }
      case "getClientId": {
        storage_default.getClientId().then((id) => sendResponse({ clientId: id }));
        break;
      }
      case "getInstalledPlugins": {
        api_default.getInstalledPlugins().then((plugins) => sendResponse({ plugins }));
        break;
      }
      case "getStorage": {
        const { pluginName, key } = params;
        api_default.getStorage(pluginName, key).then((value) => sendResponse({ value }));
        break;
      }
      case "setStorage": {
        const { pluginName, key, value } = params;
        api_default.setStorage(pluginName, key, value).then(() => sendResponse({ success: true }));
        break;
      }
      case "removeStorage": {
        const { pluginName, key } = params;
        api_default.removeStorage(pluginName, key).then(() => sendResponse({ success: true }));
        break;
      }
      default: {
        sendResponse({ error: `Unknown API method: ${method}` });
      }
    }
  }
  async function handleInputDispatch(payload, sender, sendResponse) {
    const { eventType, params } = payload;
    let tabId = sender.tab?.id;
    if (!tabId) {
      const tabs = await new Promise((resolve) => {
        chrome.tabs.query({ active: true, currentWindow: true }, resolve);
      });
      tabId = tabs[0]?.id;
    }
    if (!tabId) {
      sendResponse({ success: false, error: "\u65E0\u6CD5\u83B7\u53D6\u5F53\u524D\u6807\u7B7E\u9875" });
      return;
    }
    const cdpMethods = {
      mouse: "Input.dispatchMouseEvent",
      touch: "Input.dispatchTouchEvent",
      key: "Input.dispatchKeyEvent"
    };
    const cdpMethod = cdpMethods[eventType];
    if (!cdpMethod) {
      sendResponse({ success: false, error: `\u4E0D\u652F\u6301\u7684\u8F93\u5165\u7C7B\u578B: ${eventType}\uFF0C\u652F\u6301: mouse, touch, key` });
      return;
    }
    try {
      await new Promise((resolve, reject) => {
        chrome.debugger.attach({ tabId }, "1.3", () => {
          if (chrome.runtime.lastError) {
            const msg = chrome.runtime.lastError.message || "";
            if (msg.includes("Already attached") || msg.includes("already attached")) {
              resolve();
            } else {
              reject(new Error(msg));
            }
          } else {
            resolve();
          }
        });
      });
      const result = await new Promise((resolve, reject) => {
        chrome.debugger.sendCommand({ tabId }, cdpMethod, params, (result2) => {
          if (chrome.runtime.lastError) {
            reject(new Error(chrome.runtime.lastError.message));
          } else {
            resolve(result2);
          }
        });
      });
      sendResponse({ success: true, result });
    } catch (err) {
      sendResponse({ success: false, error: err.message });
    }
  }
  function executePluginInMainWorld(pluginName, pluginCode) {
    try {
      const ctx = {
        pluginName,
        // 发送消息到服务端（通过 postMessage → content script → background → WebSocket）
        sendMessage(message) {
          window.postMessage({
            source: "remotef-main",
            type: "plugin_message",
            payload: { pluginName, message }
          }, "*");
        },
        // 监听服务端消息
        onMessage(callback) {
          window.addEventListener("message", (event) => {
            if (event.source !== window)
              return;
            if (event.data?.source !== "remotef-isolated")
              return;
            if (event.data?.type === "server_message") {
              const msg = event.data.payload;
              if (msg?.pluginName === pluginName || !msg?.pluginName) {
                callback(msg?.message || msg);
              }
            }
          });
        },
        // 插件 API（通过 postMessage → content script → chrome.runtime.sendMessage → background）
        // 核心原则：插件只能与同名服务端插件通讯，pluginName 由系统自动绑定
        api: {
          /**
           * 发送消息给同名服务端插件
           * pluginName 由系统自动注入，插件无法指定其他插件名
           */
          sendMessage(message) {
            window.postMessage({
              source: "remotef-main",
              type: "plugin_message",
              payload: { pluginName, message }
            }, "*");
          },
          /**
           * 获取连接状态（异步）
           */
          getConnectionStatus() {
            return new Promise((resolve) => {
              window.postMessage({
                source: "remotef-main",
                type: "api_request",
                payload: { method: "getConnectionStatus", params: {} }
              }, "*");
              const handler = (event) => {
                if (event.source !== window)
                  return;
                if (event.data?.source === "remotef-isolated" && event.data?.type === "api_response") {
                  if (event.data.payload?.method === "getConnectionStatus") {
                    window.removeEventListener("message", handler);
                    resolve(event.data.payload.result);
                  }
                }
              };
              window.addEventListener("message", handler);
            });
          },
          /**
           * 获取客户端 ID（异步）
           */
          getClientId() {
            return new Promise((resolve) => {
              window.postMessage({
                source: "remotef-main",
                type: "api_request",
                payload: { method: "getClientId", params: {} }
              }, "*");
              const handler = (event) => {
                if (event.source !== window)
                  return;
                if (event.data?.source === "remotef-isolated" && event.data?.type === "api_response") {
                  if (event.data.payload?.method === "getClientId") {
                    window.removeEventListener("message", handler);
                    resolve(event.data.payload.result?.clientId);
                  }
                }
              };
              window.addEventListener("message", handler);
            });
          },
          /**
           * 获取已安装插件列表（异步）
           */
          getInstalledPlugins() {
            return new Promise((resolve) => {
              window.postMessage({
                source: "remotef-main",
                type: "api_request",
                payload: { method: "getInstalledPlugins", params: {} }
              }, "*");
              const handler = (event) => {
                if (event.source !== window)
                  return;
                if (event.data?.source === "remotef-isolated" && event.data?.type === "api_response") {
                  if (event.data.payload?.method === "getInstalledPlugins") {
                    window.removeEventListener("message", handler);
                    resolve(event.data.payload.result?.plugins || []);
                  }
                }
              };
              window.addEventListener("message", handler);
            });
          },
          /**
           * 获取插件存储（异步）
           */
          getStorage(key) {
            return new Promise((resolve) => {
              window.postMessage({
                source: "remotef-main",
                type: "api_request",
                payload: { method: "getStorage", params: { pluginName, key } }
              }, "*");
              const handler = (event) => {
                if (event.source !== window)
                  return;
                if (event.data?.source === "remotef-isolated" && event.data?.type === "api_response") {
                  if (event.data.payload?.method === "getStorage") {
                    window.removeEventListener("message", handler);
                    resolve(event.data.payload.result?.value);
                  }
                }
              };
              window.addEventListener("message", handler);
            });
          },
          /**
           * 设置插件存储（异步）
           */
          setStorage(key, value) {
            return new Promise((resolve) => {
              window.postMessage({
                source: "remotef-main",
                type: "api_request",
                payload: { method: "setStorage", params: { pluginName, key, value } }
              }, "*");
              const handler = (event) => {
                if (event.source !== window)
                  return;
                if (event.data?.source === "remotef-isolated" && event.data?.type === "api_response") {
                  if (event.data.payload?.method === "setStorage") {
                    window.removeEventListener("message", handler);
                    resolve(event.data.payload.result);
                  }
                }
              };
              window.addEventListener("message", handler);
            });
          },
          /**
           * 删除插件存储（异步）
           */
          removeStorage(key) {
            return new Promise((resolve) => {
              window.postMessage({
                source: "remotef-main",
                type: "api_request",
                payload: { method: "removeStorage", params: { pluginName, key } }
              }, "*");
              const handler = (event) => {
                if (event.source !== window)
                  return;
                if (event.data?.source === "remotef-isolated" && event.data?.type === "api_response") {
                  if (event.data.payload?.method === "removeStorage") {
                    window.removeEventListener("message", handler);
                    resolve(event.data.payload.result);
                  }
                }
              };
              window.addEventListener("message", handler);
            });
          }
        },
        // DOM 工具
        utils: {
          injectStyle(css) {
            const style = document.createElement("style");
            style.textContent = css;
            style.id = `remotef-${pluginName}-style`;
            (document.head || document.documentElement).appendChild(style);
            return style;
          },
          injectScript(code) {
            const script = document.createElement("script");
            script.textContent = code;
            (document.head || document.documentElement).appendChild(script);
            return script;
          }
        },
        /**
         * 系统级输入事件 API
         * 通过 CDP (Chrome DevTools Protocol) 发送输入事件
         * 产生 isTrusted: true 的事件，网页/滑块/防刷机制无法区分与真人操作的差异
         * 
         * 支持类型：
         *   - 'mouse': 鼠标事件 (点击、移动、滚轮)
         *   - 'touch': 触摸事件 (触摸开始/移动/结束)
         *   - 'key':   键盘事件 (按键按下/抬起)
         */
        input: {
          /**
           * 发送系统级输入事件
           * @param {string} eventType - 输入类型: 'mouse' | 'touch' | 'key'
           * @param {object} params - CDP 事件参数（不同类型参数不同）
           * @returns {Promise<{success: boolean, result?: object, error?: string}>}
           * 
           * @example
           * // 鼠标点击 (100, 200)
           * await ctx.input.dispatch('mouse', { type: 'mousePressed', x: 100, y: 200, button: 'left', clickCount: 1 });
           * await ctx.input.dispatch('mouse', { type: 'mouseReleased', x: 100, y: 200, button: 'left', clickCount: 1 });
           * 
           * // 鼠标移动
           * await ctx.input.dispatch('mouse', { type: 'mouseMoved', x: 200, y: 300 });
           * 
           * // 鼠标滚轮
           * await ctx.input.dispatch('mouse', { type: 'mouseWheel', x: 100, y: 200, deltaX: 0, deltaY: -120 });
           * 
           * // 触摸滑动
           * await ctx.input.dispatch('touch', { type: 'touchStart', touchPoints: [{ x: 100, y: 200 }] });
           * await ctx.input.dispatch('touch', { type: 'touchMove', touchPoints: [{ x: 200, y: 300 }] });
           * await ctx.input.dispatch('touch', { type: 'touchEnd', touchPoints: [] });
           * 
           * // 按键
           * await ctx.input.dispatch('key', { type: 'keyDown', key: 'Enter' });
           * await ctx.input.dispatch('key', { type: 'keyUp', key: 'Enter' });
           * 
           * // 组合键 (Ctrl+C)
           * await ctx.input.dispatch('key', { type: 'keyDown', key: 'Control' });
           * await ctx.input.dispatch('key', { type: 'keyDown', key: 'c' });
           * await ctx.input.dispatch('key', { type: 'keyUp', key: 'c' });
           * await ctx.input.dispatch('key', { type: 'keyUp', key: 'Control' });
           */
          dispatch(eventType, params) {
            return new Promise((resolve) => {
              const requestId = `input_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`;
              const handler = (event) => {
                if (event.source !== window)
                  return;
                if (event.data?.source === "remotef-isolated" && event.data?.type === "input_dispatch_response" && event.data.payload?.requestId === requestId) {
                  window.removeEventListener("message", handler);
                  resolve(event.data.payload.result);
                }
              };
              window.addEventListener("message", handler);
              setTimeout(() => {
                window.removeEventListener("message", handler);
                resolve({ success: false, error: "\u8F93\u5165\u4E8B\u4EF6\u8D85\u65F6" });
              }, 1e4);
              window.postMessage({
                source: "remotef-main",
                type: "input_dispatch",
                payload: { eventType, params, requestId }
              }, "*");
            });
          },
          /**
           * 便捷方法：点击指定坐标
           * @param {number} x - X 坐标
           * @param {number} y - Y 坐标
           * @param {object} [options] - 选项
           * @param {string} [options.button='left'] - 鼠标按钮: 'left' | 'middle' | 'right'
           * @param {number} [options.clickCount=1] - 点击次数（2=双击）
           * @param {number} [options.delay=50] - 按下与释放之间的延迟（毫秒）
           * @returns {Promise<{success: boolean}>}
           */
          async click(x, y, options = {}) {
            const { button = "left", clickCount = 1, delay = 50 } = options;
            const down = await this.dispatch("mouse", { type: "mousePressed", x, y, button, clickCount });
            if (!down.success)
              return down;
            if (delay > 0)
              await new Promise((r) => setTimeout(r, delay));
            return this.dispatch("mouse", { type: "mouseReleased", x, y, button, clickCount });
          },
          /**
           * 便捷方法：鼠标移动（带可选插值步骤，模拟真人轨迹）
           * @param {number} fromX - 起始 X
           * @param {number} fromY - 起始 Y
           * @param {number} toX - 目标 X
           * @param {number} toY - 目标 Y
           * @param {object} [options] - 选项
           * @param {number} [options.steps=5] - 插值步数
           * @param {number} [options.stepDelay=16] - 每步延迟（毫秒）
           * @returns {Promise<{success: boolean}>}
           */
          async move(fromX, fromY, toX, toY, options = {}) {
            const { steps = 5, stepDelay = 16 } = options;
            for (let i = 0; i <= steps; i++) {
              const t = i / steps;
              const x = Math.round(fromX + (toX - fromX) * t);
              const y = Math.round(fromY + (toY - fromY) * t);
              const result = await this.dispatch("mouse", { type: "mouseMoved", x, y });
              if (!result.success)
                return result;
              if (i < steps && stepDelay > 0)
                await new Promise((r) => setTimeout(r, stepDelay));
            }
            return { success: true };
          },
          /**
           * 便捷方法：触摸滑动（模拟真人手指滑动）
           * @param {number} fromX - 起始 X
           * @param {number} fromY - 起始 Y
           * @param {number} toX - 目标 X
           * @param {number} toY - 目标 Y
           * @param {object} [options] - 选项
           * @param {number} [options.steps=10] - 插值步数
           * @param {number} [options.stepDelay=16] - 每步延迟（毫秒）
           * @returns {Promise<{success: boolean}>}
           */
          async swipe(fromX, fromY, toX, toY, options = {}) {
            const { steps = 10, stepDelay = 16 } = options;
            const start = await this.dispatch("touch", { type: "touchStart", touchPoints: [{ x: fromX, y: fromY }] });
            if (!start.success)
              return start;
            for (let i = 1; i <= steps; i++) {
              const t = i / steps;
              const x = Math.round(fromX + (toX - fromX) * t);
              const y = Math.round(fromY + (toY - fromY) * t);
              const result = await this.dispatch("touch", { type: "touchMove", touchPoints: [{ x, y }] });
              if (!result.success)
                return result;
              if (i < steps && stepDelay > 0)
                await new Promise((r) => setTimeout(r, stepDelay));
            }
            return this.dispatch("touch", { type: "touchEnd", touchPoints: [] });
          },
          /**
           * 便捷方法：按键输入
           * @param {string} key - 按键名称 (如 'Enter', 'Tab', 'Escape', 'a' 等)
           * @param {object} [options] - 选项
           * @param {number} [options.delay=50] - 按下与释放之间的延迟（毫秒）
           * @returns {Promise<{success: boolean}>}
           */
          async press(key, options = {}) {
            const { delay = 50 } = options;
            const down = await this.dispatch("key", { type: "keyDown", key });
            if (!down.success)
              return down;
            if (delay > 0)
              await new Promise((r) => setTimeout(r, delay));
            return this.dispatch("key", { type: "keyUp", key });
          },
          /**
           * 便捷方法：输入文本（逐字符输入）
           * @param {string} text - 要输入的文本
           * @param {object} [options] - 选项
           * @param {number} [options.delay=50] - 每个字符之间的延迟（毫秒）
           * @returns {Promise<{success: boolean}>}
           */
          async type(text, options = {}) {
            const { delay = 50 } = options;
            for (const char of text) {
              const down = await this.dispatch("key", { type: "keyDown", key: char });
              if (!down.success)
                return down;
              const up = await this.dispatch("key", { type: "keyUp", key: char });
              if (!up.success)
                return up;
              if (delay > 0)
                await new Promise((r) => setTimeout(r, delay));
            }
            return { success: true };
          }
        }
      };
      const wrappedCode = `(function() {
      ${pluginCode}
      if (typeof __plugin__ !== 'undefined') {
        return __plugin__;
      }
      return null;
    })()`;
      const plugin = (0, eval)(wrappedCode);
      if (plugin && typeof plugin === "object") {
        window.__remotef_plugins = window.__remotef_plugins || {};
        window.__remotef_plugins[pluginName] = plugin;
        if (typeof plugin.init === "function") {
          plugin.init(ctx);
        }
        if (typeof plugin.run === "function") {
          plugin.run(ctx, plugin.config);
        }
        return { success: true, hasInit: typeof plugin.init === "function", hasRun: typeof plugin.run === "function" };
      }
      return { success: true, hasFactory: false };
    } catch (err) {
      console.error("[RemoteF Plugin Execute] Error:", err);
      return { success: false, error: err.message };
    }
  }
  function initMessageHandlers() {
    ws_client_default.on("connection_changed", (data) => {
      broadcastToPopup({ type: "connection_changed", payload: data });
    });
    ws_client_default.onMessage("connected", (payload) => {
      console.log("[RemoteF] \u8FDE\u63A5\u6210\u529F:", payload);
    });
    ws_client_default.onMessage("registered", (payload) => {
      console.log("[RemoteF] \u5DF2\u6CE8\u518C:", payload);
      ws_client_default.send({ type: "plugin_list" });
    });
    ws_client_default.onMessage("plugin_list", (payload) => {
      const plugins = Array.isArray(payload) ? payload : payload.plugins || [];
      handlePluginList(plugins);
    });
    ws_client_default.onMessage("plugin_push", async (payload) => {
      await handlePluginPush(payload);
    });
    ws_client_default.onMessage("plugin_message", (payload) => {
      api_default.handleServerMessage(payload);
      handlePluginMessage(payload);
    });
  }
  (async function init() {
    console.log("[RemoteF] \u521D\u59CB\u5316...");
    initMessageHandlers();
    setupMessageHandlers();
    await plugin_manager_default.restore((msg) => ws_client_default.send(msg));
    const config = await storage_default.getConfig();
    if (config.autoConnect && config.serverUrl) {
      console.log("[RemoteF] \u81EA\u52A8\u8FDE\u63A5...");
      ws_client_default.connect();
    }
    console.log("[RemoteF] \u521D\u59CB\u5316\u5B8C\u6210");
  })();
})();
//# sourceMappingURL=background.js.map
